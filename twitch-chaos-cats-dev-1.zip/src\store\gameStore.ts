import { create } from "zustand"

type MatchPhase =
  | "LOBBY"
  | "STARTING"
  | "IN_PROGRESS"
  | "FINISHED"

interface PlayerSnapshot {
  id: string

  nickname: string

  avatarId: string

  points: number

  eliminated: boolean
}

interface MatchEventSnapshot {
  id: string

  message: string
}

interface BoosterSnapshot {
  slot: number

  boosterName: string

  boosterIcon: string
}

interface StateUpdatePayload {
  roomId: string

  phase: MatchPhase

  tick: number

  round?: number

  currentTurnPlayerId?: string

  currentTurnStartedAt?: number

  leaderPlayerId?: string

  players: PlayerSnapshot[]

  recentEvents: MatchEventSnapshot[]

  boosterSet: BoosterSnapshot[]
}

interface GameState {
  connected: boolean

  roomId: string

  phase: MatchPhase

  tick: number

  round: number

  currentTurnPlayerId?: string

  currentTurnStartedAt?: number

  leaderPlayerId?: string

  players: PlayerSnapshot[]

  recentEvents: MatchEventSnapshot[]

  boosterSet: BoosterSnapshot[]

  setConnected: (
    connected: boolean
  ) => void

  applySnapshot: (
    snapshot: StateUpdatePayload
  ) => void
}

export const useGameStore =
  create<GameState>((set) => ({
    connected: false,

    roomId: "",

    phase: "LOBBY",

    tick: 0,

    round: 0,

    currentTurnPlayerId:
      undefined,

    currentTurnStartedAt:
      undefined,

    leaderPlayerId:
      undefined,

    players: [],

    recentEvents: [],

    boosterSet: [],

    setConnected: (
      connected
    ) =>
      set({
        connected,
      }),

    applySnapshot: (
      snapshot
    ) =>
      set({
        roomId:
          snapshot.roomId,

        phase:
          snapshot.phase,

        tick:
          snapshot.tick,

        round:
          snapshot.round ?? 0,

        currentTurnPlayerId:
          snapshot.currentTurnPlayerId,

        currentTurnStartedAt:
          snapshot.currentTurnStartedAt,

        leaderPlayerId:
          snapshot.leaderPlayerId,

        players:
          snapshot.players,

        recentEvents:
          snapshot.recentEvents,

        boosterSet:
          snapshot.boosterSet,
      }),
  }))