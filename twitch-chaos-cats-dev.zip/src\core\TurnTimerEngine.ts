import { Match } from "./Match"
import { MatchPhase } from "./matchPhase"

export class TurnTimerEngine {
  process(match: Match) {
    // таймер работает только во время выбора бустера
    if (match.phase !== MatchPhase.BOOSTER_SELECTION) {
      return
    }

    // если уже есть результат хода — ничего не делаем
    if (match.state.turnResolvedAt !== null) {
      return
    }

    // если таймер не установлен — выходим
    if (!match.state.turnEndsAt) {
      return
    }

    const now = Date.now()

    // ещё не время срабатывать
    if (now < match.state.turnEndsAt) {
      return
    }

    // фиксируем момент автозавершения
    match.state.turnResolvedAt = now

    this.activateRandomBooster(match)
  }

  private activateRandomBooster(match: Match) {
    const boosterSet = match.state.boosterSet

    if (boosterSet.length === 0) {
      return
    }

    const randomIndex = Math.floor(Math.random() * boosterSet.length)
    const randomItem = boosterSet[randomIndex]

    if (!randomItem) {
      return
    }

    if (!match.currentPlayerId) {
      return
    }

    match.transition(MatchPhase.BOOSTER_RESOLUTION)

    // ВАЖНО: используем уже существующий BoosterEngine через GameLoop,
    // а не создаём новый экземпляр здесь (избегаем рассинхронизации)
    // поэтому просто выбираем слот и отправляем через match state

    match.state.selectedBooster = {
      boosterId: randomItem.boosterId,
      sourcePlayerId: match.currentPlayerId,
      slot: randomItem.slot,
      activatedAt: Date.now(),
      autoSelected: true,
    }

    // отмечаем, что игрок сделал действие
    match.markCurrentPlayerAsPlayed()
  }
}