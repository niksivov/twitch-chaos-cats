import { CommandProcessor } from "./core/CommandProcessor"

import { GameLoop } from "./core/GameLoop"

import { MatchManager } from "./core/MatchManager"

import { SessionManager } from "./core/SessionManager"

import { GameBroadcaster } from "./network/GameBroadcaster"

import { GameWebSocketServer } from "./network/WebSocketServer"

const sessionManager =
  new SessionManager()

const matchManager =
  new MatchManager(
    sessionManager
  )

const commandProcessor =
  new CommandProcessor(
    matchManager
  )

const websocketServer =
  new GameWebSocketServer(8080)

const broadcaster =
  new GameBroadcaster(
    websocketServer
  )

const gameLoop =
  new GameLoop(
    matchManager,
    commandProcessor,
    broadcaster
  )

const match =
  matchManager.createMatch()

console.log(
  "MATCH ID:",
  match.id
)

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_1",

  payload: {
    nickname: "catViewer",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_2",

  payload: {
    nickname: "secondCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_3",

  payload: {
    nickname: "thirdCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_4",

  payload: {
    nickname: "fourthCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_5",

  payload: {
    nickname: "fifthCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_6",

  payload: {
    nickname: "sosixCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_7",

  payload: {
    nickname: "sseventhCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_8",

  payload: {
    nickname: "eighthCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_9",

  payload: {
    nickname: "ninthCat",
  },

  createdAt: Date.now(),
})

commandProcessor.enqueue({
  type: "JOIN",

  matchId: match.id,

  playerId: "player_10",

  payload: {
    nickname: "tenthCat",
  },

  createdAt: Date.now(),
})

console.log(
  "PLAYERS AFTER ENQUEUE:",
  match.players
)

setTimeout(() => {
  console.log(
    "PLAYERS AFTER PROCESS:",
    match.players
  )
}, 3000)

gameLoop.start()

console.log("server started")

console.log(
  "websocket running on :8080"
)